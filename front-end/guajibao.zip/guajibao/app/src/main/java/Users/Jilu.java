package Users;

public class Jilu  {
    private  String time;
    private String  price;
    public Jilu(String time,String price){
        this.time=time;
        this.price=price;
    }
    public String getPrice() {
        return price;
    }

    public String getTime() {
        return time;
    }
}
