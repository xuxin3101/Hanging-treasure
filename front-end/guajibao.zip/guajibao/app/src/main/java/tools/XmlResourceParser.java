package tools;

/**
 * 黄俊杰
 * 2018/6/15
 */
public interface XmlResourceParser extends XmlPullParser, AttributeSet {
    void close();
}

