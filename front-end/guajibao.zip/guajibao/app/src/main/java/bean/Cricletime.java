package bean;

public class Cricletime {
    private String cricletime;

    public String getCricletime() {
        return cricletime;
    }

    public void setCricletime(String cricletime) {
        this.cricletime = cricletime;
    }
}
