package bean;

public class MinWithDraw {
    private String minwithwraw;

    public String getMinwithwraw() {
        return minwithwraw;
    }

    public void setMinwithwraw(String minwithwraw) {
        this.minwithwraw = minwithwraw;
    }
}
