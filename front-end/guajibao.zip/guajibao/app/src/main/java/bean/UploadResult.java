package bean;

public class UploadResult {
    private String result;
    private String url;

    public String getResult() {
        return result;
    }

    public String getUrl() {
        return url;
    }
    public void setResult(String result) {
        this.result = result;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
