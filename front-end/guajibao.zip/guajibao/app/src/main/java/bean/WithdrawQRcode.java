package bean;

public class WithdrawQRcode {
    private String wecheatqrcode;
    private String alipayqrcode;

    public String getAlipayqrcode() {
        return alipayqrcode;
    }

    public String getWecheatqrcode() {
        return wecheatqrcode;
    }

    public void setAlipayqrcode(String alipayqrcode) {
        this.alipayqrcode = alipayqrcode;
    }

    public void setWecheatqrcode(String wecheatqrcode) {
        this.wecheatqrcode = wecheatqrcode;
    }
}
